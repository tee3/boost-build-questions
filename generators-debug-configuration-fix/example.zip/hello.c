void hello ();

int
main ()
{
   hello ();
}
