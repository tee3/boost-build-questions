#include <stdio.h>

void hello ()
{
   printf ("Hello, world!\n");
}
